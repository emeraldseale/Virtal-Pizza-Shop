#include <string>
#include <iostream>

struct orders {

	int orderNum;
	string customerName;
	int creditCard;
	string address;
	string customerPhone;
	string pizzaName;
	int size;
	int quantity;	
};
